import os, sys

script_dir = os.path.dirname( os.path.realpath(__file__) )
sys.path.insert(0, script_dir + os.sep + "lib")

def handler(event, context): 
  print "hello world!"
  return {"hello": "world!"}
